# Corpus_burlesque
Les dossiers "Mazarinades" contient les écrits burlesques parus pendant la Fronde, essentiellement en vers, et disponibles en ligne au 31/12/2020.
Ils sont regroupés en 4 sous-dossiers alphabétiques.

Les textes de ce corpus de contraste ont été choisis à partir des ouvrages de référence sur le sujet et de leur disponibilité en ligne. "Burlesque" peut y être entendu au sens large. Les ouvrages utilisés sont :

    Bar, Francis. 1960. Le Genre burlesque en France au xviie siècle. Étude de style. Paris : Éditions D’Artrey
    Nédélec, Claudine. 2004. Les États et empires du burlesque. Paris : Honoré Champion


